# yahia
this is new
# myprogram
this is repo
this is project is a c++ bot on Aylol Cpllege that contains files on files inside project.cpp
PROJECT CONTENTS :
project.cpp / main.cpp contains the main file for the program code
project.cpp /it.txt pharmacy.txt nursing.txt business.txt midwifery.txt managers.txt contains for files

USAGE :
it is used by asking the user question about Aylol College information such as the (Introduction , caders , admission criteria )
it.txt / contains information on information technology 
pharmacy.txt / information on pharmacy
nursing.txt / information on nursing 
midwifery.txt / information on midwifery
business.txt / information on business administration 
aylol.txt / information on aylol college 
managers.txt / information on managers Aylol College 

*each major contains for (introduction , caders and admission criteria )
*if the user enter a question that does not exite ,he is transferred to the (openHelpOpnation) function and chooes what he wants
who want ? from (CHATGPT  OR GOOGLE ).

EXAMPLE :
if he enter ---> who are caders to it ? it takes the important words and opens the it file by examining the question
than you get the answer from files 

But if he enter --> what is c++ ?
it is maved to a OpenHelpOpnation function for chooses.
